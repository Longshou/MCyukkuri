/* Render the exported triangles using the same rasterizer as the user gallery. */
const fs=require('fs'),path=require('path'),vm=require('vm');
const {pathToFileURL}=require('url');
const root=path.resolve(__dirname,'../../../..');
const {chromium}=require(path.join(root,'tools/browser-check/node_modules/playwright-core'));
const crypto=require('crypto');
const hash=file=>crypto.createHash('sha256').update(fs.readFileSync(file)).digest('hex');
(async()=>{
 const browser=await chromium.launch({headless:true,executablePath:'C:/Program Files/Google/Chrome/Application/chrome.exe'});
 const report={startedAt:new Date().toISOString(),previewDataSha256:hash(path.join(__dirname,'previews/current/data.js')),exportsSha256:hash(path.join(__dirname,'reports/current/exports.json')),viewerSha256:hash(path.join(__dirname,'previews/current/viewer.js')),checks:[],errors:[]};
 try{
  const page=await browser.newPage({viewport:{width:1440,height:1050},deviceScaleFactor:1});
  page.on('pageerror',e=>report.errors.push(e.message));
  await page.goto(pathToFileURL(path.join(__dirname,'previews/current/index.html')).href);
  await page.waitForFunction(()=>window.propsPreview?.ready());
  await page.screenshot({path:path.join(__dirname,'previews/current/gallery.png'),fullPage:true});
  const assets=await page.evaluate(()=>propsPreview.assets());
  for(const category of ['block','item','attachment']){
   await page.locator(`[data-filter="${category}"]`).click();
   const count=await page.locator('.card').count();if(count!==assets.filter(x=>x.category===category).length)throw Error('Category mismatch');
   await page.screenshot({path:path.join(__dirname,`previews/current/${category}-sheet.png`),fullPage:true});
   report.checks.push({category,count});
  }
  for(const a of assets){
   await page.evaluate(id=>propsPreview.open(id),a.id);
   for(const angle of ['oblique','front','side','back']){
    await page.locator(`[data-view="${angle}"]`).click();
    await page.locator('#view').screenshot({path:path.join(__dirname,`previews/current/${a.id}-${angle}.png`)});
   }
   await page.locator('.close').click();
  }
  await page.locator('[data-filter="all"]').click();
  await page.locator('#search').fill('绷带');if(await page.locator('.card').count()!==2)throw Error('Search mismatch');
  await page.locator('#search').fill('');
  await page.locator('[data-id="food_bowl"]').click();
  await page.locator('#states button').filter({hasText:'满粮'}).click();
  if((await page.evaluate(()=>propsPreview.state())).selected!=='food_bowl_full')throw Error('State switch mismatch');
  const box=await page.locator('#view').boundingBox();
  await page.mouse.move(box.x+200,box.y+200);await page.mouse.down();await page.mouse.move(box.x+250,box.y+220,{steps:4});await page.mouse.up();await page.mouse.wheel(0,-100);
  await page.waitForTimeout(150);
  const state=await page.evaluate(()=>propsPreview.state());if(state.az===.5||state.zoom===1)throw Error('Orbit/zoom failed');
  await page.locator('#reset').click();if((await page.evaluate(()=>propsPreview.state())).zoom!==1)throw Error('Reset failed');
  await page.keyboard.press('Escape');if(await page.locator('#detail').evaluate(e=>e.open))throw Error('Close failed');
  report.checks.push('30 assets, four real geometry views each','search','state switch','drag orbit','wheel zoom','reset','Escape closes');
  await page.setViewportSize({width:390,height:844});await page.screenshot({path:path.join(__dirname,'previews/current/mobile.png'),fullPage:true});
  if(await page.evaluate(()=>document.documentElement.scrollWidth>innerWidth))throw Error('Mobile overflow');
  report.checks.push('390px mobile layout without horizontal overflow');
  report.ok=!report.errors.length;
 } finally {
  fs.writeFileSync(path.join(__dirname,'reports/current/browser.json'),JSON.stringify(report,null,2));await browser.close();
 }
 if(report.errors.length)throw Error(report.errors.join('\n'));
 console.log(JSON.stringify(report));
})();
