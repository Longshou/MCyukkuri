/* No CDN, no service, no network dependency; supports direct file opening. */
const $=id=>document.getElementById(id), textures=new Map();
const groups={block:['方块类','5 种放置设施 · 食盆和沙厕包含不同状态'],item:['物品类','15 种携带与掉落道具 · 帽子和蝴蝶结沿用角色几何'],attachment:['附属物','随身体或巢穴显示 · 不作为独立方块或可拾取物品']};
const stateGroups=[['food_bowl','food_bowl_full','food_bowl_low'],['yukkuri_toilet','yukkuri_toilet_dirty'],['house_egg','house_egg_cracked'],['birth_stem','spent_stem']];
let filter='all',selected=null,az=.5,el=.42,zoom=1,drag=null,ready=false;
function framing(a){return {centerY:a.dims[1]/2,span:Math.max(a.dims[1],Math.hypot(a.dims[0],a.dims[2])*.87)*.67};}
function draw(canvas,a,yaw=.5,pitch=.42,z=1){
 const t=textures.get(a.id);if(!t)return;
 const f=framing(a);canvas.getContext('2d').putImageData(new ImageData(renderModel(a.model.vertices,t,canvas.width,canvas.height,yaw,pitch,f.span*z,{centerY:f.centerY,textureSize:a.model.texture_size}),canvas.width,canvas.height),0,0);
}
function gallery(){
 const query=$('search').value.trim().toLowerCase(),root=$('gallery');root.replaceChildren();let count=0;
 for(const [category,[label,note]] of Object.entries(groups)){
  if(filter!=='all'&&filter!==category)continue;
  const assets=ASSETS.filter(a=>a.category===category&&(!query||(a.label+' '+a.id).toLowerCase().includes(query)));if(!assets.length)continue;
  const section=document.createElement('section');section.dataset.category=category;
  const heading=document.createElement('div');heading.className='section-heading';
  const h=document.createElement('h2');h.textContent=label;const p=document.createElement('p');p.textContent=note;heading.append(h,p);
  const grid=document.createElement('div');grid.className='grid';
  for(const a of assets){
   const b=document.createElement('button');b.className='card';b.dataset.id=a.id;b.setAttribute('aria-label','查看'+a.label);
   const im=document.createElement('div');im.className='image-wrap';const c=document.createElement('canvas');c.width=380;c.height=260;
   const num=document.createElement('span');num.className='num';num.textContent=String(ASSETS.indexOf(a)+1).padStart(2,'0');
   const tag=document.createElement('span');tag.className='tag';tag.textContent=a.state==='常态'?'3D':a.state;
   const cap=document.createElement('div');cap.className='caption';const name=document.createElement('h3');name.textContent=a.label;const code=document.createElement('small');code.textContent=a.id;
   cap.append(name,code);im.append(c,num,tag);b.append(im,cap);b.onclick=()=>openAsset(a.id);grid.append(b);draw(c,a);count++;
  }
  section.append(heading,grid);root.append(section);
 }
 if(!count){const e=document.createElement('p');e.className='empty';e.textContent='没有匹配的素材。';root.append(e);}
}
function paint(){if(selected)draw($('view'),selected,az,el,zoom);}
function openAsset(id){
 selected=ASSETS.find(a=>a.id===id);az=.5;el=.42;zoom=1;
 $('detail-title').textContent=selected.label;$('detail-type').textContent=groups[selected.category][0];$('detail-note').textContent=selected.note;
 $('metadata').textContent=`尺寸 ${selected.dims.map(n=>n.toFixed(2)).join(' × ')} 单位（宽 × 高 × 深） · ${selected.triangles.toLocaleString()} 三角面`;
 $('download').href=selected.bbmodel;
 $('states').replaceChildren();const family=stateGroups.find(g=>g.includes(id));
 if(family)for(const k of family){const a=ASSETS.find(x=>x.id===k),b=document.createElement('button');b.className='small-button'+(k===id?' active':'');b.textContent=a.state==='常态'?a.label:a.state;b.onclick=()=>openAsset(k);$('states').append(b);}
 if(!$('detail').open)$('detail').showModal();paint();
}
for(const b of document.querySelectorAll('[data-filter]'))b.onclick=()=>{filter=b.dataset.filter;for(const tab of document.querySelectorAll('[data-filter]'))tab.setAttribute('aria-selected',String(tab===b));gallery();};
$('search').oninput=gallery;
document.querySelector('.close').onclick=()=>$('detail').close();
$('detail').onclick=e=>{if(e.target===$('detail')){const r=$('detail').getBoundingClientRect();if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom)$('detail').close();}};
for(const b of document.querySelectorAll('[data-view]'))b.onclick=()=>{const angles={front:[0,.06],oblique:[.5,.42],side:[Math.PI/2,.12],back:[Math.PI,.18],top:[0,1.45]};[az,el]=angles[b.dataset.view];paint();};
$('reset').onclick=()=>{az=.5;el=.42;zoom=1;paint();};
$('view').onpointerdown=e=>{drag=[e.clientX,e.clientY];$('view').setPointerCapture(e.pointerId);};
$('view').onpointermove=e=>{if(!drag)return;az+=(e.clientX-drag[0])*.01;el=Math.max(-1.4,Math.min(1.5,el+(e.clientY-drag[1])*.01));drag=[e.clientX,e.clientY];paint();};
$('view').onpointerup=$('view').onpointercancel=()=>drag=null;
$('view').onwheel=e=>{e.preventDefault();zoom=Math.max(.4,Math.min(2.5,zoom*Math.exp(e.deltaY*.001)));paint();};
Promise.all(ASSETS.map(a=>new Promise((resolve,reject)=>{const im=new Image();im.onload=()=>{const c=document.createElement('canvas');c.width=im.width;c.height=im.height;const ctx=c.getContext('2d');ctx.drawImage(im,0,0);textures.set(a.id,ctx.getImageData(0,0,im.width,im.height).data);resolve();};im.onerror=reject;im.src=a.texture;}))).then(()=>{ready=true;gallery();}).catch(e=>{$('gallery').textContent='贴图读取失败：'+e;});
window.propsPreview={ready:()=>ready,open:openAsset,assets:()=>ASSETS.map(({id,category})=>({id,category})),state:()=>({selected:selected?.id,az,el,zoom,filter}),draw};
