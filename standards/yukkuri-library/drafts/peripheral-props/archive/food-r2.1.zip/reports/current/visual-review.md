# R2.1 食盆修订检查

2026-09-12。本轮仅调整盆内油粮与原版草料，并补充食物标签。当前 35 个状态：方块设施 12、物品 16、附属物 7。本记录不表示用户已确认标准。

## 适用来源

- `build.py`：`6d2bfd76e3416e652932dcba7cf9ad125a491a5c1118974afe2b0a55ccca27a6`
- `revision2.py`：`1fc0fd839a7c198d2663125207106bde255431542ae0acbdd650cae4139139fb`
- `native_forage.py`：`9241b90a9f3cd11db8b2357c4b4fe9905d8fbbf42f2540ef8b17af0d1f5d130e`
- `presentation-rules.json`：`d459acb9231f8fbf1c9d35123ba89f34df6a425762ac4e4457be83b7b6ff25c3`

每件导出指纹见 [exports.json](exports.json)，实际浏览器输入指纹、范围和结果见 [browser.json](browser.json)。

## 本轮已执行

- 同步生成 35 个状态的源配套导出，检查有限坐标、非零尺寸和 UV 边界。
- 全部食盆重生成正、斜、侧、背四视角；实际查看原版短草、小麦斜视图，可辨原版透明轮廓，盆体未被替换。预览草色固定，游戏颜色仍由原版渲染决定。
- 浏览器确认三档盆内油粮顶点与贴图像素完全相同；短草和小麦 0／1／4／8 份递增，零份无内容。
- 分类、搜索、状态切换、拖动旋转、滚轮缩放、复位、Esc、390 像素布局通过，无脚本异常。
- `processResources --offline` 通过。食物标签引用及打包处理结果见 [forage-integration.json](forage-integration.json)。

## 前轮范围与未覆盖项

体型、漏馅、短茎组合、标签、长卵的 R2 审查见 [前轮记录](../../archive/visual-review-r2.md)，仅适用于对应未改几何；本轮没有重新执行独立 agent 审查。食盆修改前基线见 [food-r2.zip](../../archive/food-r2.zip)。

未执行 Minecraft 实机喂食、Blockbench 应用导入、新模型游戏接入、动态身体挂接或药效验收。浏览器检查进程已关闭。中文记录人工审校，未运行不可用的文风技能。
