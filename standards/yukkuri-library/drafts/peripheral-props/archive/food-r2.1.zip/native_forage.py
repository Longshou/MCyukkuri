"""Preview real Minecraft forage sprites; runtime keeps using vanilla item IDs.
The local preview atlas embeds local-client pixels only for offline inspection.
No Minecraft textures are copied into the mod's packaged resources.
"""
from pathlib import Path
import hashlib, io, math, os, zipfile
from PIL import Image

def add_native_forage(model,kind,units=8):
    jar=Path(os.environ.get('MC_CLIENT_JAR',str(Path.home()/'.gradle/caches/neoformruntime/artifacts/minecraft_1.21.1_client.jar')))
    resource='assets/minecraft/textures/item/wheat.png' if kind=='wheat' else 'assets/minecraft/textures/block/short_grass.png'
    with zipfile.ZipFile(jar) as z:raw=z.read(resource)
    sprite=Image.open(io.BytesIO(raw)).convert('RGBA')
    if kind!='wheat':
        # Fixed preview tint. The actual game item renderer supplies biome/resource-pack tint.
        tint=(145,189,89)
        sprite.putdata([tuple(p[i]*tint[i]//255 for i in range(3))+(p[3],) for p in sprite.getdata()])
    atlas=Image.new('RGBA',(512,512));atlas.paste(model.texture,(0,0));atlas.paste(sprite,(256,0));model.texture=atlas
    item='minecraft:wheat' if kind=='wheat' else 'minecraft:short_grass'
    model.sources.append(dict(resource=resource,item=item,minecraft_version='1.21.1',source_archive='minecraft_1.21.1_client.jar',sha256=hashlib.sha256(raw).hexdigest(),preview_tint=None if kind=='wheat' else '#91bd59',runtime='reference vanilla resource; do not ship copied pixels'))
    for unit in range(1,units+1):
        a=(unit-1)*2.399963;r=math.sqrt((unit-.5)/units)*3.1;cx=r*math.cos(a);cz=r*.85*math.sin(a)
        points=[];faces={};uv=[[256,16],[272,16],[272,0],[256,0]]
        for plane in range(2):
            angle=a+plane*math.pi/2;dx=math.cos(angle)*1.32;dz=math.sin(angle)*1.32
            p=[[cx-dx,.66,cz-dz],[cx+dx,.66,cz+dz],[cx+dx+.25,3.05,cz+dz],[cx-dx+.25,3.05,cz-dz]]
            start=len(points);points+=p
            # Crossed, double-sided vanilla sprite planes; transparent pixels keep the original silhouette.
            for tri in [[0,2,1],[0,3,2],[0,1,2],[0,2,3]]:
                keys=[str(start+i) for i in tri];faces[str(len(faces))]=dict(vertices=keys,uv={str(start+i):uv[i] for i in tri},texture=0)
        model.parts.append(dict(name='vanilla_'+kind+'_'+str(unit),type='mesh',unit=unit,origin=[0,0,0],rotation=[0,0,0],vertices={str(i):p for i,p in enumerate(points)},faces=faces))
