package io.github.longshou.mcyukkuri.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.math.Axis;
import io.github.longshou.mcyukkuri.MCYukkuri;
import io.github.longshou.mcyukkuri.entity.YukkuriEntity;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.culling.Frustum;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;
import net.minecraft.client.Minecraft;
import net.minecraft.world.item.ItemDisplayContext;

public final class YukkuriRenderer extends EntityRenderer<YukkuriEntity> {
    public YukkuriRenderer(EntityRendererProvider.Context context) {
        super(context);
        shadowRadius = .32f;
    }

    @Override
    public boolean shouldRender(YukkuriEntity entity, Frustum frustum, double x, double y, double z) {
        if (super.shouldRender(entity, frustum, x, y, z)) return true;
        // The body-sized collision box excludes tall hats and animated stretches.
        double margin = entity.broodCount()>0?3:entity.getVariant().isHouse() ? .4 : 1.2;
        return entity.shouldRender(x, y, z) && frustum.isVisible(entity.getBoundingBoxForCulling().inflate(margin));
    }

    @Override
    public ResourceLocation getTextureLocation(YukkuriEntity entity) {
        String expression = entity.getVariant().isHouse() && entity.getAnimationId().equals("puff")
                ? "angry" : entity.getExpressionId();
        return MCYukkuri.id("textures/entity/" + entity.getVariant().assetId() + "/" + expression + ".png");
    }

    @Override
    public void render(YukkuriEntity entity, float yaw, float partialTick, PoseStack pose,
                       MultiBufferSource buffers, int packedLight) {
        shadowRadius = (entity.getVariant().isHouse() ? .12f : .32f)*entity.growthScale();
        if (!entity.isInvisible()) {
            pose.pushPose();
            pose.mulPose(Axis.YP.rotationDegrees(180 - Mth.rotLerp(partialTick, entity.yBodyRotO, entity.yBodyRot)));
            if (entity.deathTime > 0) pose.mulPose(Axis.ZP.rotationDegrees(Math.min(90, (entity.deathTime + partialTick) * 4.5f)));
            pose.scale(entity.getScale(),entity.getScale(),entity.getScale());
            pose.pushPose();pose.scale(entity.growthScale(),entity.growthScale(),entity.growthScale());
            var model=YukkuriModel.get(entity.getVariant().assetId());
            String contact=entity.contactPose();boolean operated=!contact.equals("NONE")&&!contact.equals("SLIDE");
            if(contact.equals("BOX"))PropModels.render("iron_enclosure_"+entity.getVariant().assetId(),1,pose,buffers,packedLight,OverlayTexture.NO_OVERLAY);
            if(contact.equals("FIXED")||contact.equals("WRAPPED")){
                PropModels.render((contact.equals("FIXED")?"restraint_frame_":"wrap_sling_")+entity.getVariant().assetId()+(entity.hasVisibleAccessory()?"":"_bare"),1,pose,buffers,packedLight,OverlayTexture.NO_OVERLAY);
            }
            float contactAngle=switch(contact){case "SUPINE","FIXED","HOOK"->90;case "ROLL"->entity.contactTurn();case "RUMP"->-12;default->0;};
            float lift=contact.equals("FIXED")?PropModels.bodyLift("restraint_frame_"+entity.getVariant().assetId()+(entity.hasVisibleAccessory()?"":"_bare")):
                    contactAngle==0?0:model.contactLift(contactAngle,entity.hasVisibleAccessory(),entity.visibleHairLoss());
            pose.pushPose();
            if(contactAngle!=0){
                pose.translate(0,lift,0);
                pose.mulPose(Axis.XP.rotationDegrees(contactAngle));
            }
            if(contact.equals("GRIP"))pose.scale(1.1f,.85f,1.1f);
            if(contact.equals("VIBRATE"))pose.translate(Math.sin((entity.tickCount+partialTick)*2)*.008,0,0);
            float elapsed = Math.max(0, (entity.level().getGameTime() - entity.getAnimationStartTick() + partialTick) / 20f);
            int overlay = OverlayTexture.pack(0, entity.hurtTime > 0 || entity.deathTime > 0);
            var buffer = buffers.getBuffer(RenderType.entityCutoutNoCull(getTextureLocation(entity)));
            String behavior = entity.getBehaviorId();
            float phaseTicks = Math.max(0, entity.level().getGameTime() - entity.getBehaviorStartTick() + partialTick);
            if (behavior.equals("sleep_enter")) pose.scale(1, 1 - Math.min(1, phaseTicks/20)*.04f, 1);
            else if (behavior.equals("sleep")) pose.scale(1, .96f, 1);
            else if (behavior.equals("wake")) pose.scale(1, .96f + Math.min(1, phaseTicks/20)*.04f, 1);
            model.setCarrying(!entity.getCarriedItem().isEmpty());
            model.renderLiving(operated?"idle":entity.getAnimationId(), operated?0:elapsed, pose, buffer, packedLight, overlay,
                    entity.hasVisibleAccessory(), operated?"idle":behavior, phaseTicks,entity.visibleHairLoss(),entity,buffers);
            if(entity.visibleMedal()>0){
                var point=model.surfacePoint();pose.pushPose();pose.translate(-point.x,point.y,point.z-.006);
                pose.mulPose(Axis.YP.rotationDegrees(180));pose.scale(.14f,.14f,.14f);
                var badge=new net.minecraft.world.item.ItemStack(entity.visibleMedal()==2?io.github.longshou.mcyukkuri.human.HumanWorld.GOLD_BADGE.get():io.github.longshou.mcyukkuri.human.HumanWorld.SILVER_BADGE.get());
                Minecraft.getInstance().getItemRenderer().renderStatic(badge,ItemDisplayContext.FIXED,packedLight,overlay,pose,buffers,entity.level(),entity.getId());pose.popPose();
            }
            var presentation=LivingPresentation.variants.get(entity.getVariant().assetId());
            for(int heldIndex=0;heldIndex<2;heldIndex++){
                var held=heldIndex==0?entity.getMouthItem():entity.getCarriedItem();
                if(held.isEmpty())continue;
                var grip=heldIndex==1?model.gripPoint():null;
                pose.pushPose();
                if(grip!=null)pose.translate(grip.x,grip.y,grip.z);
                else pose.translate(presentation.x(),presentation.y(),presentation.z());
                float itemScale=grip!=null&&held.is(io.github.longshou.mcyukkuri.registry.ModItems.FOOD_SCRAP.get())?HouseScrapRenderer.HELD_SCALE:presentation.foodScale();
                pose.scale(itemScale,itemScale,itemScale);
                Minecraft.getInstance().getItemRenderer().renderStatic(held,ItemDisplayContext.FIXED,packedLight,overlay,
                        pose,buffers,entity.level(),entity.getId());
                pose.popPose();
            }
            if(contact.equals("PIN"))model.renderSurfaceProp("pin_tool",1,.6f,pose,buffers,packedLight,OverlayTexture.NO_OVERLAY);
            if(contact.equals("VIBRATE"))model.renderSurfaceProp("care_vibrator",1,1,pose,buffers,packedLight,OverlayTexture.NO_OVERLAY);
            if(contact.equals("HOOK")||contact.equals("WRAPPED"))OperationAttachments.render(entity,model,pose,buffers,packedLight,contactAngle,lift,partialTick);
            pose.popPose();
            pose.popPose();
            FamilyRenderer.render(entity,pose,buffers,packedLight);
            pose.popPose();
        }
        super.render(entity, yaw, partialTick, pose, buffers, packedLight);
        SpeechBubble.render(entity, partialTick, pose, buffers, packedLight);
    }
}
