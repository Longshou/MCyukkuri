package io.github.longshou.mcyukkuri.entity;

import io.github.longshou.mcyukkuri.MCYukkuri;
import io.github.longshou.mcyukkuri.dialogue.NativeDialogue;
import io.github.longshou.mcyukkuri.dialogue.SpeechTiming;
import io.github.longshou.mcyukkuri.life.YukkuriLife;
import io.github.longshou.mcyukkuri.social.YukkuriSocial;
import io.github.longshou.mcyukkuri.family.FamilyLife;
import io.github.longshou.mcyukkuri.registry.ModItems;
import java.util.EnumSet;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.TagKey;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.PathfinderMob;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.TemptGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.util.DefaultRandomPos;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.item.crafting.Ingredient;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.pathfinder.PathType;
import net.minecraft.world.level.gameevent.GameEvent;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.event.EventHooks;

/** Server-owned behaviour and actions. Clients only sample synchronized poses. */
public final class YukkuriEntity extends PathfinderMob {
    public static final TagKey<Item> FOOD = TagKey.create(Registries.ITEM, MCYukkuri.id("yukkuri_food"));
    private static final EntityDataAccessor<String> ANIMATION = SynchedEntityData.defineId(YukkuriEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Long> ANIMATION_START = SynchedEntityData.defineId(YukkuriEntity.class, EntityDataSerializers.LONG);
    private static final EntityDataAccessor<String> EXPRESSION = SynchedEntityData.defineId(YukkuriEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<String> BEHAVIOR = SynchedEntityData.defineId(YukkuriEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Long> BEHAVIOR_START = SynchedEntityData.defineId(YukkuriEntity.class, EntityDataSerializers.LONG);
    private static final EntityDataAccessor<String> DIALOGUE = SynchedEntityData.defineId(YukkuriEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Long> SPEECH_START = SynchedEntityData.defineId(YukkuriEntity.class, EntityDataSerializers.LONG);
    private static final EntityDataAccessor<Long> SPEECH_END = SynchedEntityData.defineId(YukkuriEntity.class, EntityDataSerializers.LONG);
    private static final EntityDataAccessor<Integer> SPEECH_SEQUENCE = SynchedEntityData.defineId(YukkuriEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<ItemStack> MOUTH = SynchedEntityData.defineId(YukkuriEntity.class, EntityDataSerializers.ITEM_STACK);
    private static final EntityDataAccessor<Integer> MEDAL = SynchedEntityData.defineId(YukkuriEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> ACCESSORY = SynchedEntityData.defineId(YukkuriEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Float> GROWTH_SCALE = SynchedEntityData.defineId(YukkuriEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Integer> LIFE_STAGE = SynchedEntityData.defineId(YukkuriEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> BROOD_COUNT = SynchedEntityData.defineId(YukkuriEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> BROOD_BORN = SynchedEntityData.defineId(YukkuriEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> BROOD_TYPES = SynchedEntityData.defineId(YukkuriEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Float> BROOD_PROGRESS = SynchedEntityData.defineId(YukkuriEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> BROOD_VARIATION = SynchedEntityData.defineId(YukkuriEntity.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Boolean> SPENT_STEM = SynchedEntityData.defineId(YukkuriEntity.class, EntityDataSerializers.BOOLEAN);
    private final YukkuriVariant variant;
    private final YukkuriLife life;
    private final YukkuriSocial social;
    private final io.github.longshou.mcyukkuri.social.GroupInteractionGoal groupInteraction = new io.github.longshou.mcyukkuri.social.GroupInteractionGoal(this);
    private final io.github.longshou.mcyukkuri.life.SurfaceLife surfaceLife=new io.github.longshou.mcyukkuri.life.SurfaceLife(this);
    private final FamilyLife family;
    private final io.github.longshou.mcyukkuri.settlement.SettlementLife settlement;
    private final io.github.longshou.mcyukkuri.settlement.HabitatLife habitat;
    private final io.github.longshou.mcyukkuri.house.HouseLife house;
    private final io.github.longshou.mcyukkuri.body.BodyLife body;
    private final io.github.longshou.mcyukkuri.interaction.OperationLife operations;
    private static final EntityDataAccessor<Integer> WOUND=SynchedEntityData.defineId(YukkuriEntity.class,EntityDataSerializers.INT);
    private static final EntityDataAccessor<CompoundTag> WOUNDS=SynchedEntityData.defineId(YukkuriEntity.class,EntityDataSerializers.COMPOUND_TAG);
    private static final EntityDataAccessor<Integer> FILLING=SynchedEntityData.defineId(YukkuriEntity.class,EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> BANDAGED=SynchedEntityData.defineId(YukkuriEntity.class,EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<ItemStack> CARRYING=SynchedEntityData.defineId(YukkuriEntity.class,EntityDataSerializers.ITEM_STACK);
    private static final EntityDataAccessor<String> CONTACT_POSE=SynchedEntityData.defineId(YukkuriEntity.class,EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Float> CONTACT_TURN=SynchedEntityData.defineId(YukkuriEntity.class,EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<java.util.Optional<net.minecraft.core.BlockPos>> CONTACT_ANCHOR=SynchedEntityData.defineId(YukkuriEntity.class,EntityDataSerializers.OPTIONAL_BLOCK_POS);
    private static final EntityDataAccessor<Integer> HAIR_LOSS=SynchedEntityData.defineId(YukkuriEntity.class,EntityDataSerializers.INT);
    private boolean deathRecorded;
    private YukkuriAction requestedAction;
    private int panicTicks;
    private int foodCooldown;
    // Retained only to migrate pre-P1 saves; nutrition and loaded-time physiology live in YukkuriLife.
    private int restDelay = 600;
    private int reactionTicks;
    private final SpeechTiming speechTiming = new SpeechTiming();
    private final net.minecraft.util.RandomSource speechRandom = net.minecraft.util.RandomSource.create();
    private String reactionExpression = "neutral";

    public YukkuriEntity(EntityType<? extends YukkuriEntity> type, Level level, YukkuriVariant variant) {
        super(type, level);
        this.variant = variant;
        this.life = new YukkuriLife(this);
        this.social = new YukkuriSocial(this);
        this.family = new FamilyLife(this);
        this.settlement = new io.github.longshou.mcyukkuri.settlement.SettlementLife(this);
        this.habitat = new io.github.longshou.mcyukkuri.settlement.HabitatLife(this);
        this.house = new io.github.longshou.mcyukkuri.house.HouseLife(this);
        this.body = new io.github.longshou.mcyukkuri.body.BodyLife(this);
        this.operations = new io.github.longshou.mcyukkuri.interaction.OperationLife(this);
        setPathfindingMalus(PathType.WATER, -1);
        setPathfindingMalus(PathType.WATER_BORDER, 8);
        setPathfindingMalus(PathType.DANGER_FIRE, 16);
        setPathfindingMalus(PathType.DAMAGE_FIRE, -1);
    }

    public YukkuriVariant getVariant() { return variant; }
    public String getAnimationId() { return entityData.get(ANIMATION); }
    public long getAnimationStartTick() { return entityData.get(ANIMATION_START); }
    public String getExpressionId() { return entityData.get(EXPRESSION); }
    public String getBehaviorId() { return entityData.get(BEHAVIOR); }
    public long getBehaviorStartTick() { return entityData.get(BEHAVIOR_START); }
    public String getDialogueKey() { return entityData.get(DIALOGUE); }
    public long speechStart() { return entityData.get(SPEECH_START); }
    public long speechEnd() { return entityData.get(SPEECH_END); }
    public int speechSequence() { return entityData.get(SPEECH_SEQUENCE); }
    public ItemStack getMouthItem() { return entityData.get(MOUTH); }
    public int visibleMedal() { return entityData.get(MEDAL); }
    public boolean hasVisibleAccessory() { return entityData.get(ACCESSORY); }
    public boolean isPanicking() { return panicTicks > 0; }
    public boolean isCommandPlaying() { return requestedAction != null; }
    public YukkuriLife life() { return life; }
    public YukkuriSocial social() { return social; }
    public io.github.longshou.mcyukkuri.social.GroupInteractionGoal groupInteraction() { return groupInteraction; }
    public io.github.longshou.mcyukkuri.life.SurfaceLife surfaceLife(){return surfaceLife;}
    public void frightenFrom(YukkuriEntity threat) {
        if(level().isClientSide||!isAlive())return;
        operations.end();groupInteraction.stop();social.stop();life.interrupt();
        setLastHurtByMob(threat);panicTicks=100;
    }
    public FamilyLife family() { return family; }
    public io.github.longshou.mcyukkuri.settlement.SettlementLife settlement() { return settlement; }
    public io.github.longshou.mcyukkuri.settlement.HabitatLife habitat() { return habitat; }

    @Override public net.minecraft.world.entity.SpawnGroupData finalizeSpawn(net.minecraft.world.level.ServerLevelAccessor level,
            net.minecraft.world.DifficultyInstance difficulty, net.minecraft.world.entity.MobSpawnType reason,
            net.minecraft.world.entity.SpawnGroupData data) {
        var result = super.finalizeSpawn(level, difficulty, reason, data);
        if (reason == net.minecraft.world.entity.MobSpawnType.NATURAL || reason == net.minecraft.world.entity.MobSpawnType.CHUNK_GENERATION)
            settlement.naturalSpawn();
        return result;
    }
    public io.github.longshou.mcyukkuri.house.HouseLife house(){return house;}
    public ItemStack getCarriedItem(){return entityData.get(CARRYING);}
    public io.github.longshou.mcyukkuri.body.BodyLife body(){return body;}
    public io.github.longshou.mcyukkuri.interaction.OperationLife operations(){return operations;}
    public String contactPose(){return entityData.get(CONTACT_POSE);}
    public float contactTurn(){return entityData.get(CONTACT_TURN);}
    public int visibleHairLoss(){return entityData.get(HAIR_LOSS);}
    public void syncOperation(String pose,float turn){entityData.set(CONTACT_POSE,pose);entityData.set(CONTACT_TURN,turn);if(pose.equals("NONE"))syncOperationAnchor(null);}
    public void syncOperationAnchor(net.minecraft.core.BlockPos anchor){entityData.set(CONTACT_ANCHOR,java.util.Optional.ofNullable(anchor));}
    public net.minecraft.core.BlockPos contactAnchor(){return entityData.get(CONTACT_ANCHOR).orElse(null);}
    public int visibleWound(){return entityData.get(WOUND);}
    public java.util.List<io.github.longshou.mcyukkuri.body.BodyWound> visibleWounds(){return io.github.longshou.mcyukkuri.body.BodyWound.read(entityData.get(WOUNDS));}
    public int visibleFilling(){return entityData.get(FILLING);}
    public void syncBody(){if(body==null||level().isClientSide)return;entityData.set(WOUND,Math.max(body.wound(),body.burns()));entityData.set(WOUNDS,io.github.longshou.mcyukkuri.body.BodyWound.write(body.wounds()));entityData.set(FILLING,body.filling());entityData.set(BANDAGED,body.bandage()>0);entityData.set(HAIR_LOSS,body.hairLoss());}
    public boolean visibleBandage(){return entityData.get(BANDAGED);}
    public float growthScale() { return entityData.get(GROWTH_SCALE); }
    public int lifeStage() { return entityData.get(LIFE_STAGE); }
    public int broodCount() { return entityData.get(BROOD_COUNT); }
    public int broodBornMask() { return entityData.get(BROOD_BORN); }
    public float broodProgress() { return entityData.get(BROOD_PROGRESS); }
    public float broodVariation() { return entityData.get(BROOD_VARIATION); }
    public boolean hasSpentStem() { return entityData.get(SPENT_STEM); }
    public YukkuriVariant broodVariant(int index) { return YukkuriVariant.values()[(entityData.get(BROOD_TYPES)>>(index*3))&7]; }
    public void syncFamily() {
        if(family==null||level().isClientSide)return;
        entityData.set(GROWTH_SCALE,family.scale());entityData.set(LIFE_STAGE,family.stage().ordinal());
        var brood=family.brood();int count=family.spentStemCount(),born=(1<<count)-1,types=0;float progress=1,variation=family.spentStemVariation();
        if(brood!=null&&!brood.cancelled&&brood.kind==io.github.longshou.mcyukkuri.family.FamilyData.BirthKind.STEM) {
            count=brood.children.size();born=0;progress=brood.progress();variation=brood.variation;
            for(int i=0;i<count;i++){var child=brood.children.get(i);if(child.born)born|=1<<i;types|=child.variant.ordinal()<<(i*3);}
        }
        entityData.set(BROOD_COUNT,count);entityData.set(BROOD_BORN,born);entityData.set(BROOD_TYPES,types);
        entityData.set(BROOD_PROGRESS,progress);entityData.set(BROOD_VARIATION,variation);entityData.set(SPENT_STEM,family.spentStemCount()>0);
    }
    @Override protected net.minecraft.world.entity.EntityDimensions getDefaultDimensions(net.minecraft.world.entity.Pose pose) {
        return getType().getDimensions().scale(growthScale());
    }
    @Override public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        super.onSyncedDataUpdated(key);if(GROWTH_SCALE.equals(key))refreshDimensions();
    }
    @Override public boolean isBaby() { return lifeStage()!=FamilyLife.Stage.ADULT.ordinal(); }
    @Override public boolean causeFallDamage(float distance,float multiplier,DamageSource damage) {
        return family!=null&&family.awaitingLanding()?false:super.causeFallDamage(distance,multiplier*io.github.longshou.mcyukkuri.life.Facilities.landing(io.github.longshou.mcyukkuri.life.Facilities.floor(this)),damage);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        super.defineSynchedData(builder);
        builder.define(ANIMATION, "idle");
        builder.define(ANIMATION_START, 0L);
        builder.define(EXPRESSION, "neutral");
        builder.define(BEHAVIOR, "idle"); builder.define(DIALOGUE, "");
        builder.define(SPEECH_START, 0L); builder.define(SPEECH_END, 0L); builder.define(SPEECH_SEQUENCE, 0);
        builder.define(BEHAVIOR_START, 0L);
        builder.define(MEDAL, 0); builder.define(MOUTH, ItemStack.EMPTY); builder.define(ACCESSORY, true);
        builder.define(CARRYING,ItemStack.EMPTY);
        builder.define(WOUND,0);builder.define(BANDAGED,false);
        builder.define(WOUNDS,new CompoundTag());builder.define(FILLING,12);
        builder.define(CONTACT_POSE,"NONE");builder.define(CONTACT_TURN,0f);builder.define(HAIR_LOSS,0);builder.define(CONTACT_ANCHOR,java.util.Optional.empty());
        builder.define(GROWTH_SCALE,1f);builder.define(LIFE_STAGE,FamilyLife.Stage.ADULT.ordinal());
        builder.define(BROOD_COUNT,0);builder.define(BROOD_BORN,0);builder.define(BROOD_TYPES,0);
        builder.define(BROOD_PROGRESS,0f);builder.define(BROOD_VARIATION,1f);builder.define(SPENT_STEM,false);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return PathfinderMob.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 10.0)
                .add(Attributes.MOVEMENT_SPEED, 0.18)
                .add(Attributes.FOLLOW_RANGE, 16.0)
                .add(Attributes.STEP_HEIGHT, 1.0);
    }

    @Override
    protected void registerGoals() {
        goalSelector.addGoal(0, new EscapeWaterGoal());
        goalSelector.addGoal(0, new HouseExitGoal());
        goalSelector.addGoal(0, new OperationGoal());
        goalSelector.addGoal(1, new FleeGoal());
        goalSelector.addGoal(2, new HoldActionGoal());
        goalSelector.addGoal(3, new LifeGoal());
        goalSelector.addGoal(4, new io.github.longshou.mcyukkuri.human.FactoryWorkGoal(this));
        goalSelector.addGoal(4, new TemptGoal(this, 1.15, Ingredient.of(FOOD), false) {
            @Override public boolean canUse() { return life.needsFood() && super.canUse() && life.personality().fear(player.getUUID()) < 30; }
            @Override public boolean canContinueToUse() { return life.needsFood() && super.canContinueToUse(); }
        });
        goalSelector.addGoal(5, new FamilyGoal());
        goalSelector.addGoal(5, new HouseGoal());
        goalSelector.addGoal(4, new io.github.longshou.mcyukkuri.settlement.ForageGoal(this));
        goalSelector.addGoal(4, new HabitatGoal());
        goalSelector.addGoal(6, new SettlementGoal());
        goalSelector.addGoal(6, new SocialGoal());
        goalSelector.addGoal(5, new GroupGoal());
        goalSelector.addGoal(7, new WaterAvoidingRandomStrollGoal(this, 1.0));
        goalSelector.addGoal(8, new LookAtPlayerGoal(this, Player.class, 6.0F));
        goalSelector.addGoal(9, new RandomLookAroundGoal(this));
    }

    /** One exclusive track: changing action or returning to idle discards every previous pose. */
    public boolean playAction(String id) {
        if (level().isClientSide || !isAlive()) return false;
        var action = YukkuriAction.byId(id);
        if (action.isEmpty()) return false;
        operations.end();groupInteraction.stop();life.interrupt(); social.stop();
        YukkuriAction next = action.get();
        long elapsedRetractionTicks = 0;
        if (id.endsWith("_retract")) {
            String extension = id.replace("_retract", "_extend");
            if (requestedAction == null || !requestedAction.id().equals(extension)) {
                // Retracting an already hidden part must not reveal its fully extended first frame.
                next = YukkuriAction.IDLE;
            } else {
                double extensionProgress = Mth.clamp((level().getGameTime() - getAnimationStartTick())
                        / (requestedAction.duration() * 20.0), 0.0, 1.0);
                // Both source clips use symmetric smoothstep curves; reverse from the current pose.
                elapsedRetractionTicks = Math.round((1.0 - extensionProgress) * next.duration() * 20.0);
            }
        }
        requestedAction = next == YukkuriAction.IDLE ? null : next;
        restDelay = 200;
        panicTicks = 0;
        navigation.stop();
        setAnimation(next, true);
        entityData.set(ANIMATION_START, level().getGameTime() - elapsedRetractionTicks);
        if (next == YukkuriAction.PUFF) speak("puff");
        return true;
    }

    private void setAnimation(YukkuriAction action, boolean restart) {
        if (restart || !getAnimationId().equals(action.id())) {
            entityData.set(ANIMATION_START, level().getGameTime());
            entityData.set(ANIMATION, action.id());
        }
    }

    @Override
    public void aiStep() {
        super.aiStep();
        if (level().isClientSide || !isAlive()) return;
        if (reactionTicks > 0) reactionTicks--;
        if (level().getGameTime() >= speechEnd()) entityData.set(DIALOGUE, "");
        life.tick(); social.tick();operations.tick(); family.tick();house.tick();settlement.tick();habitat.tick();groupInteraction.clock();syncFamily();
        entityData.set(CARRYING,(variant.isHouse()?house.carrying():habitat.carrying()).copy());
        body.tick();syncBody();
        surfaceLife.tick();
        if(!isAlive())return;
        if (!ItemStack.matches(entityData.get(MOUTH), life.mouth())) entityData.set(MOUTH, life.mouth().copy());
        entityData.set(MEDAL, life.medal()); entityData.set(ACCESSORY, life.hasAccessory());
        if (isOnFire() && panicTicks < 100) {
            panicTicks = 100;
            requestedAction = null;
            life.interrupt(); social.stop();
        }
        if (panicTicks > 0) {
            setAnimation(panicTicks > 100 ? YukkuriAction.STARTLE : YukkuriAction.FLEE, false);
            panicTicks--;
            entityData.set(EXPRESSION, "surprise");
            setBehavior(isInWaterOrBubble() ? "escape_water" : "flee");
            return;
        }
        if (requestedAction != null && !requestedAction.loops() && !requestedAction.holdsEndPose()
                && level().getGameTime() - getAnimationStartTick() >= requestedAction.durationTicks()) {
            requestedAction = null;
        }
        YukkuriAction action = requestedAction != null ? requestedAction
                : getDeltaMovement().horizontalDistanceSqr() > 0.0001 && !life.isSleeping()
                ? YukkuriAction.WADDLE : groupInteraction.active()?YukkuriAction.PUFF:YukkuriAction.IDLE;
        setAnimation(action, false);
        setBehavior(isInWaterOrBubble() ? "escape_water" : !life.activity().equals("idle") ? life.activity()
                : groupInteraction.active()?groupInteraction.activity():family.active() ? family.activity() : house.active()?house.activity():habitat.active()?habitat.activity():settlement.active()?settlement.activity():social.active() ? social.activity() : family.activity());
        entityData.set(EXPRESSION, life.isSleeping() || family.awaitingLanding() ? "sleep" : reactionTicks > 0 ? reactionExpression : life.hasAccessory() ? "neutral" : "surprise");
    }

    private void setBehavior(String behavior) {
        if (!getBehaviorId().equals(behavior)) {
            entityData.set(BEHAVIOR, behavior); entityData.set(BEHAVIOR_START, level().getGameTime());
        }
    }

    public void showReaction(String expression, String dialogue, int ticks) {
        if (level().isClientSide) return;
        reactionTicks = ticks; reactionExpression = expression;
        speak(dialogue);
    }

    public boolean speak(String event) {
        if (level().isClientSide || !isAlive()) return false;
        String species = variant.dialogueSpecies();
        var line = NativeDialogue.select(species, family.youngVoice(), event, speechRandom);
        long now = level().getGameTime();
        if (line == null || !speechTiming.admit(now, line.ticks(), NativeDialogue.priority(event))) return false;
        entityData.set(DIALOGUE, line.key());
        entityData.set(SPEECH_START, now); entityData.set(SPEECH_END, speechTiming.end());
        entityData.set(SPEECH_SEQUENCE, speechSequence() + 1);
        return true;
    }

    @Override
    public boolean hurt(DamageSource source, float amount) {
        float before=getHealth();
        boolean damaged = super.hurt(source, amount);
        if (damaged && !level().isClientSide && isAlive()) {
            body.injured(source,before-getHealth());
            groupInteraction.stop();
            if(source.getEntity() instanceof YukkuriEntity attacker)io.github.longshou.mcyukkuri.social.GroupInteractionGoal.witnessedAttack(this,attacker);
            operations.damaged(source);
            requestedAction = null;
            life.interrupt(); social.stop();
            life.personality().hurt(source.getEntity() instanceof Player player ? player.getUUID() : null);
            panicTicks = 112;
            navigation.stop();
            setAnimation(YukkuriAction.STARTLE, true);
        }
        return damaged;
    }

    @Override
    public void die(DamageSource source) {
        if (!level().isClientSide) {
            groupInteraction.stop();
            requestedAction = null;
            operations.end();
            if(!deathRecorded) { deathRecorded=true;family.died();house.dropCarrying();habitat.dropCarrying();body.died(); }
            life.interrupt(); social.stop(); life.releaseHome();
            setAnimation(YukkuriAction.IDLE, true);
            entityData.set(EXPRESSION, "neutral");
        }
        super.die(source);
    }

    @Override
    protected InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (stack.isEmpty()) {
            if (!level().isClientSide) {
                if(player.isSecondaryUseActive())io.github.longshou.mcyukkuri.interaction.CareMenu.open(player,this);
                else social.talk(player,true);
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        if (stack.is(Items.SHEARS) && player.isSecondaryUseActive()) {
            if (!level().isClientSide) {
                var token = life.takeAccessory(player.getUUID());
                if (token != null) {
                    ItemStack accessory = new ItemStack(ModItems.accessoryFor(variant));
                    CustomData.update(DataComponents.CUSTOM_DATA, accessory, data -> { data.putUUID("Owner",getUUID()); data.putUUID("Token",token);data.putFloat("SourceScale",family.scale()*(variant.isHouse()?.32f:1)); });
                    if (!player.getInventory().add(accessory)) player.drop(accessory, false);
                }
            }
            return InteractionResult.sidedSuccess(level().isClientSide);
        }
        if (!life.acceptsFood(stack) || !life.canEat()) {
            return super.mobInteract(player, hand);
        }
        if (!level().isClientSide) {
            ItemStack one = stack.copyWithCount(1);
            if (life.beginMeal(one, player.getUUID(), false) && !player.getAbilities().instabuild) stack.shrink(1);
        }
        return InteractionResult.sidedSuccess(level().isClientSide);
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("YukkuriFoodCooldown", foodCooldown);
        tag.putInt("YukkuriRestDelay", restDelay);
        tag.put("YukkuriLife", life.save());
        tag.put("YukkuriGroupInteraction",groupInteraction.save());
        tag.put("YukkuriSurface",surfaceLife.save());
        tag.put("YukkuriFamily", family.save());tag.putBoolean("FamilyDeathRecorded",deathRecorded);
        tag.put("YukkuriHouse",house.save());
        tag.put("YukkuriBody",body.save());
        tag.put("YukkuriOperations",operations.save());
        tag.put("YukkuriSettlement",settlement.save());
        tag.put("YukkuriHabitat",habitat.save());
        // Command poses and transient anatomy states never survive a world reload.
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        foodCooldown = Mth.clamp(tag.getInt("YukkuriFoodCooldown"), 0, 600);
        restDelay = tag.contains("YukkuriRestDelay") ? Mth.clamp(tag.getInt("YukkuriRestDelay"), 0, 1200) : 600;
        if (tag.contains("YukkuriLife")) life.load(tag.getCompound("YukkuriLife"));
        else {
            net.minecraft.nbt.CompoundTag migrated = new net.minecraft.nbt.CompoundTag();
            migrated.putFloat("Nutrition", foodCooldown > 0 ? 85 : 60); migrated.putInt("RestWait", restDelay);
            life.load(migrated);
        }
        requestedAction = null;
        panicTicks = reactionTicks = 0;
        groupInteraction.load(tag.getCompound("YukkuriGroupInteraction"));
        surfaceLife.load(tag.getCompound("YukkuriSurface"));
        setAnimation(YukkuriAction.IDLE, true);
        entityData.set(EXPRESSION, "neutral");
        entityData.set(MEDAL, life.medal()); entityData.set(ACCESSORY, life.hasAccessory()); entityData.set(MOUTH, life.mouth().copy());
        if(tag.contains("YukkuriFamily"))family.load(tag.getCompound("YukkuriFamily"));
        deathRecorded=tag.getBoolean("FamilyDeathRecorded");
        if(tag.contains("YukkuriHouse"))house.load(tag.getCompound("YukkuriHouse"));
        if(tag.contains("YukkuriBody"))body.load(tag.getCompound("YukkuriBody"));
        operations.load(tag.getCompound("YukkuriOperations"));
        settlement.load(tag.getCompound("YukkuriSettlement"));
        habitat.load(tag.getCompound("YukkuriHabitat"));
        entityData.set(HAIR_LOSS,body.hairLoss());
    }

    private final class OperationGoal extends Goal {
        OperationGoal(){setFlags(EnumSet.of(Flag.MOVE,Flag.LOOK));}
        @Override public boolean canUse(){return operations.controlling();}
        @Override public boolean canContinueToUse(){return operations.controlling();}
        @Override public boolean requiresUpdateEveryTick(){return true;}
        @Override public void start(){navigation.stop();}
        @Override public void tick(){navigation.stop();}
    }

    private final class HoldActionGoal extends Goal {
        HoldActionGoal() { setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK)); }
        @Override public boolean canUse() { return requestedAction != null; }
        @Override public boolean requiresUpdateEveryTick() { return true; }
        @Override public void start() { navigation.stop(); }
        @Override public void tick() { navigation.stop(); }
    }

    private final class FleeGoal extends Goal {
        FleeGoal() { setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK)); }
        @Override public boolean canUse() { return panicTicks > 0; }
        @Override public boolean requiresUpdateEveryTick() { return true; }
        @Override public void tick() {
            if (panicTicks > 100) { navigation.stop(); return; }
            if (navigation.isDone() || tickCount % 10 == 0) {
                Vec3 target = getLastHurtByMob() == null ? DefaultRandomPos.getPos(YukkuriEntity.this, 6, 3)
                        : DefaultRandomPos.getPosAway(YukkuriEntity.this, 6, 3, getLastHurtByMob().position());
                if (target != null) navigation.moveTo(target.x, target.y, target.z, 1.7);
            }
        }
        @Override public void stop() { navigation.stop(); }
    }

    private final class LifeGoal extends Goal {
        LifeGoal() { setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK)); }
        @Override public boolean canUse() { return life.plan(); }
        @Override public boolean canContinueToUse() { return life.plan(); }
        @Override public boolean requiresUpdateEveryTick() { return true; }
        @Override public void tick() { life.tickGoal(); }
        @Override public void stop() { life.stopGoal(); }
    }
    private final class HabitatGoal extends Goal {
        HabitatGoal() { setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK)); }
        @Override public boolean canUse() { return habitat.canUse(); }
        @Override public boolean canContinueToUse() { return habitat.canContinue(); }
        @Override public boolean requiresUpdateEveryTick() { return true; }
        @Override public void tick() { habitat.tickGoal(); }
        @Override public void stop() { habitat.stop(); }
    }

    private final class SettlementGoal extends Goal {
        SettlementGoal() { setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK)); }
        @Override public boolean canUse() { return settlement.canUse(); }
        @Override public boolean canContinueToUse() { return settlement.canContinue(); }
        @Override public boolean requiresUpdateEveryTick() { return true; }
        @Override public void tick() { settlement.tickGoal(); }
        @Override public void stop() { settlement.stop(); }
    }

    private final class GroupGoal extends Goal {
        GroupGoal(){setFlags(EnumSet.of(Flag.MOVE,Flag.LOOK));}
        @Override public boolean canUse(){return groupInteraction.canUse();}
        @Override public boolean canContinueToUse(){return groupInteraction.canContinueToUse();}
        @Override public boolean requiresUpdateEveryTick(){return true;}
        @Override public void tick(){groupInteraction.tick();}
        @Override public void stop(){groupInteraction.stop();}
    }
    private final class SocialGoal extends Goal {
        SocialGoal() { setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK)); }
        @Override public boolean canUse() { return social.canUse(); }
        @Override public boolean canContinueToUse() { return social.canContinue(); }
        @Override public boolean requiresUpdateEveryTick() { return true; }
        @Override public void tick() { social.tickGoal(); }
        @Override public void stop() { social.stop(); }
    }
    private final class EscapeWaterGoal extends Goal {
        EscapeWaterGoal() { setFlags(EnumSet.of(Flag.MOVE, Flag.JUMP)); }
        @Override public boolean canUse() { return isInWaterOrBubble(); }
        @Override public boolean requiresUpdateEveryTick() { return true; }
        @Override public void tick() { life.escapeWater(); }
        @Override public void stop() { navigation.stop(); }
    }
    private final class HouseExitGoal extends Goal {
        HouseExitGoal(){setFlags(EnumSet.of(Flag.MOVE));}
        @Override public boolean canUse(){return house.mustExit();}
        @Override public boolean canContinueToUse(){return house.mustExit();}
        @Override public boolean requiresUpdateEveryTick(){return true;}
        @Override public void tick(){house.tickExit();}
    }
    private final class HouseGoal extends Goal {
        HouseGoal(){setFlags(EnumSet.of(Flag.MOVE,Flag.LOOK));}
        @Override public boolean canUse(){return house.canUse();}
        @Override public boolean canContinueToUse(){return house.canContinue();}
        @Override public boolean requiresUpdateEveryTick(){return true;}
        @Override public void tick(){house.tickGoal();}
        @Override public void stop(){house.stop();}
    }
    private final class FamilyGoal extends Goal {
        FamilyGoal() { setFlags(EnumSet.of(Flag.MOVE,Flag.LOOK)); }
        @Override public boolean canUse() { return family.canUse(); }
        @Override public boolean canContinueToUse() { return family.canContinue(); }
        @Override public boolean requiresUpdateEveryTick() { return true; }
        @Override public void tick() { family.tickGoal(); }
        @Override public void stop() { family.stop(); }
    }
}
