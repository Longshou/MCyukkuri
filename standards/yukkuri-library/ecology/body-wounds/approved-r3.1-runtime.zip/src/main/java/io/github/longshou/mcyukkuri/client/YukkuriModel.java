package io.github.longshou.mcyukkuri.client;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import io.github.longshou.mcyukkuri.MCYukkuri;
import io.github.longshou.mcyukkuri.entity.YukkuriVariant;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.server.packs.resources.ResourceManagerReloadListener;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/** Numeric authoring rig with triangle geometry and two-bone skinning. Client only. */
public final class YukkuriModel {
    public static final ResourceManagerReloadListener RELOAD = YukkuriModel::reload;
    private static Map<String, YukkuriModel> models = Map.of();
    private static final float DEGREES = (float) (Math.PI / 180);
    private final float[] vertices;
    private final String id;
    private final String sourceHash;
    private boolean warnedWoundMismatch;
    private final Binding[] bindings;
    private final Bone[] bones;
    private final List<Part> parts = new ArrayList<>();
    private int woundTriangle=-1;
    private boolean drawingWoundedBody;
    private int[] gripBones;
    private Vector3f[] gripPoints;
    private boolean gripping,carrying;
    public void setCarrying(boolean value){carrying=value;}
    private final Map<String, Clip> clips = new HashMap<>();
    // Rendering is serial on the render thread; these buffers are not entity state.
    private final Matrix4f[] world;
    private final float[][] pose;
    private final Vector3f[] triangle = {new Vector3f(), new Vector3f(), new Vector3f()};
    private final Vector3f second = new Vector3f(), normal = new Vector3f(), edge = new Vector3f();

    private record Bone(String name, int parent, float x, float y, float z) {}
    private record Binding(int first, int second, float weight) {}
    private record Part(String name, int start, int count, String anatomy) {}
    private record Track(int bone, int offset, float[][] keys) {
        void sample(float time, float[] target) {
            int low = 0, high = keys.length - 1;
            while (high - low > 1) {
                int middle = (low + high) >>> 1;
                if (keys[middle][0] <= time) low = middle;
                else high = middle;
            }
            float[] a = keys[low], b = keys[Math.min(low + 1, keys.length - 1)];
            float q = b[0] == a[0] ? 0 : Math.clamp((time - a[0]) / (b[0] - a[0]), 0f, 1f);
            for (int i = 0; i < 3; i++) target[offset + i] = a[i + 1] + (b[i + 1] - a[i + 1]) * q;
        }
    }
    private record Clip(float duration, boolean loop, List<Track> tracks) {
        void sample(float elapsed, float[][] pose) {
            float time = loop ? Math.max(0, elapsed) % duration : Math.clamp(elapsed, 0f, duration);
            for (Track track : tracks) track.sample(time, pose[track.bone]);
        }
    }

    public static YukkuriModel get(String id) {
        YukkuriModel model = models.get(id);
        if (model == null) throw new IllegalStateException("Yukkuri resources were not loaded: " + id);
        return model;
    }

    /** Attach to the actual posed skin; call directly after rendering this same body. */
    public void renderWound(PoseStack target,net.minecraft.client.renderer.MultiBufferSource buffers,int light,int overlay,int severity) {
        renderSurfaceProp("wound_patch",Math.min(8,severity),1,target,buffers,light,overlay);
    }
    public void renderSurfaceProp(String name,int units,float scale,PoseStack target,net.minecraft.client.renderer.MultiBufferSource buffers,int light,int overlay) {
        locateSurface();
        if(woundTriangle<0)return;
        for(int i=0;i<3;i++)skin(woundTriangle+i,triangle[i]);
        var origin=new Vector3f(triangle[0]).add(triangle[1]).add(triangle[2]).div(48);
        var normal=new Vector3f(triangle[1]).sub(triangle[0]).cross(new Vector3f(triangle[2]).sub(triangle[0]));
        if(normal.lengthSquared()<1e-10)return;normal.normalize();if(normal.z>0)normal.negate();
        var right=new Vector3f(normal).cross(0,1,0);if(right.lengthSquared()<1e-10)return;right.normalize();
        var up=new Vector3f(right).cross(normal).normalize();
        var basis=new org.joml.Matrix3f(right,normal,up);var rotation=new org.joml.Quaternionf().setFromNormalized(basis);
        target.pushPose();target.translate(origin.x+normal.x*.002,origin.y+normal.y*.002,origin.z+normal.z*.002);target.mulPose(rotation);
        float factor=(id.startsWith("house_")?.22f:.65f)*scale;target.scale(factor,factor,factor);
        PropModels.render(name,units,target,buffers,light,overlay);target.popPose();
    }
    private void locateSurface(){
        if(woundTriangle<0){
            float x=id.startsWith("house_")?1.2f:3.6f,y=id.startsWith("house_")?1.4f:2.2f,z=id.startsWith("house_")?-1.65f:-4.8f;
            float best=Float.MAX_VALUE;
            for(var part:parts)if(part.name.startsWith("soft_head_slice_")||part.name.equals("house_body_surface")){
                for(int first=part.start;first<part.start+part.count;first+=3){
                    float a=0,b=0,c=0;for(int i=0;i<3;i++){int v=(first+i)*8;a+=vertices[v]/3;b+=vertices[v+1]/3;c+=vertices[v+2]/3;}
                    float distance=(a-x)*(a-x)+(b-y)*(b-y)+(c-z)*(c-z);if(distance<best){best=distance;woundTriangle=first;}
                }
            }
        }
    }

    public org.joml.Vector3f surfacePoint(){
        locateSurface();
        if(woundTriangle<0)return new org.joml.Vector3f(0,.2f,-.3f);
        var point=new org.joml.Vector3f();var vertex=new org.joml.Vector3f();
        for(int i=0;i<3;i++){skin(woundTriangle+i,vertex);point.add(vertex);}return point.div(48);
    }
    private static void reload(ResourceManager manager) {
        Map<String, YukkuriModel> loaded = new HashMap<>();
        for (YukkuriVariant variant : YukkuriVariant.values()) {
            String id = variant.assetId();
            try (var stream = manager.getResourceOrThrow(MCYukkuri.id("yukkuri/" + id + ".json")).open()) {
                byte[] bytes=stream.readAllBytes();String hash;
                try{hash=java.util.HexFormat.of().formatHex(java.security.MessageDigest.getInstance("SHA-256").digest(bytes));}catch(java.security.NoSuchAlgorithmException impossible){throw new IllegalStateException(impossible);}
                loaded.put(id, new YukkuriModel(JsonParser.parseString(new String(bytes,java.nio.charset.StandardCharsets.UTF_8)).getAsJsonObject(),hash));
            } catch (IOException error) {
                throw new UncheckedIOException("Cannot load Yukkuri model " + id, error);
            }
        }
        LivingPresentation.reload(manager);
        WoundRenderer.clear();
        models = Map.copyOf(loaded);
    }

    private YukkuriModel(JsonObject data,String hash) {
        sourceHash=hash;
        id = data.get("id").getAsString();
        if (data.get("format").getAsInt() != 1 || data.get("units_per_block").getAsInt() != 16)
            throw new IllegalArgumentException("Unsupported Yukkuri model format");
        vertices = floats(data.getAsJsonArray("vertices"));
        JsonArray sourceBones = data.getAsJsonArray("bones");
        bones = new Bone[sourceBones.size()];
        world = new Matrix4f[bones.length];
        pose = new float[bones.length][9];
        for (int i = 0; i < bones.length; i++) {
            JsonObject bone = sourceBones.get(i).getAsJsonObject();
            float[] pivot = floats(bone.getAsJsonArray("pivot"));
            int parent = bone.get("parent").getAsInt();
            if (parent < -1 || parent >= i) throw new IllegalArgumentException("Unordered bone hierarchy");
            bones[i] = new Bone(bone.get("name").getAsString(), parent, pivot[0], pivot[1], pivot[2]);
            world[i] = new Matrix4f();
        }
        JsonArray sourceBindings = data.getAsJsonArray("weights");
        bindings = new Binding[sourceBindings.size()];
        if (vertices.length != bindings.length * 8) throw new IllegalArgumentException("Invalid vertex stride");
        for (int i = 0; i < bindings.length; i++) {
            JsonArray values = sourceBindings.get(i).getAsJsonArray();
            int a = values.get(0).getAsInt(), b = values.get(1).getAsInt();
            float weight = values.get(2).getAsFloat();
            if (a < 0 || a >= bones.length || b < 0 || b >= bones.length || weight < 0 || weight > 1)
                throw new IllegalArgumentException("Invalid vertex binding");
            bindings[i] = new Binding(a, b, weight);
        }
        for (var value : data.getAsJsonArray("parts")) {
            JsonObject part = value.getAsJsonObject();
            int start = part.get("start").getAsInt(), count = part.get("count").getAsInt();
            if (start < 0 || count < 0 || count % 3 != 0 || start + count > bindings.length)
                throw new IllegalArgumentException("Invalid triangle range");
            parts.add(new Part(part.get("name").getAsString(), start, count, part.get("anatomy").getAsString()));
        }
        JsonObject allClips=data.getAsJsonObject("clips").deepCopy();
        if(data.has("behavior_clips"))for(var entry:data.getAsJsonObject("behavior_clips").entrySet())allClips.add(entry.getKey(),entry.getValue());
        if(data.has("grip")){
            var grip=data.getAsJsonObject("grip");gripBones=new int[2];gripPoints=new Vector3f[2];
            for(int i=0;i<2;i++){gripBones[i]=grip.getAsJsonArray("bones").get(i).getAsInt();
                float[] point=floats(grip.getAsJsonArray("points").get(i).getAsJsonArray());gripPoints[i]=new Vector3f(point);}
        }
        for (var entry : allClips.entrySet()) {
            JsonObject clip = entry.getValue().getAsJsonObject();
            List<Track> tracks = new ArrayList<>();
            for (var value : clip.getAsJsonArray("tracks")) {
                JsonObject track = value.getAsJsonObject();
                int offset = switch (track.get("channel").getAsString()) {
                    case "position" -> 0;
                    case "rotation" -> 3;
                    case "scale" -> 6;
                    default -> throw new IllegalArgumentException("Unknown animation channel");
                };
                JsonArray keys = track.getAsJsonArray("keys");
                float[][] samples = new float[keys.size()][];
                for (int i = 0; i < samples.length; i++) samples[i] = floats(keys.get(i).getAsJsonArray());
                int bone = track.get("bone").getAsInt();
                if (bone < 0 || bone >= bones.length || samples.length == 0)
                    throw new IllegalArgumentException("Invalid animation track");
                tracks.add(new Track(bone, offset, samples));
            }
            float duration = clip.get("duration").getAsFloat();
            if (!(duration > 0)) throw new IllegalArgumentException("Invalid clip duration");
            clips.put(entry.getKey(), new Clip(duration, clip.get("loop").getAsBoolean(), tracks));
        }
        if (!clips.containsKey("idle")) throw new IllegalArgumentException("Missing idle defaults");
    }

    private static float[] floats(JsonArray values) {
        float[] result = new float[values.size()];
        for (int i = 0; i < result.length; i++) {
            result[i] = values.get(i).getAsFloat();
            if (!Float.isFinite(result[i])) throw new IllegalArgumentException("Non-finite model value");
        }
        return result;
    }

    public void render(String action, float elapsed, PoseStack stack, VertexConsumer buffer, int light, int overlay) {
        render(action, elapsed, stack, buffer, light, overlay, true, "idle", 0);
    }

    public void render(String action, float elapsed, PoseStack stack, VertexConsumer buffer, int light, int overlay,
            boolean accessory, String behavior, float behaviorTicks) {
        render(action,elapsed,stack,buffer,light,overlay,accessory,behavior,behaviorTicks,0);
    }
    public void render(String action, float elapsed, PoseStack stack, VertexConsumer buffer, int light, int overlay,
            boolean accessory, String behavior, float behaviorTicks,int hairLoss) {
        for (float[] values : pose) {
            java.util.Arrays.fill(values, 0);
            values[6] = values[7] = values[8] = 1;
        }
        clips.get("idle").sample(0, pose); // Sparse clips retain hidden puff defaults.
        String selected=action;
        if(gripBones!=null&&(action.equals("idle")||action.equals("waddle"))){
            if(behavior.equals("house_pickup")||behavior.equals("house_deposit")||behavior.equals("house_carry"))selected=behavior;
            else if(action.equals("waddle")&&(behavior.equals("house_scavenge")||behavior.equals("seek_food")||behavior.equals("house_enter")||behavior.equals("house_exit")))selected="house_crawl";
        }
        if(carrying&&gripBones!=null&&(selected.equals("idle")||selected.equals("waddle")))selected="house_carry";
        gripping=carrying||selected.equals("house_pickup")||selected.equals("house_deposit")||selected.equals("house_carry");
        clips.getOrDefault(selected, clips.get("idle")).sample(selected.equals(action)?elapsed:behaviorTicks/20f, pose);
        if(carrying&&gripBones!=null&&!selected.equals("house_pickup")&&!selected.equals("house_deposit")&&!selected.equals("house_carry")){
            // Carry survives interruption; only the lock joints override another body action.
            for(Track track:clips.get("house_carry").tracks)if(track.bone==gripBones[0]||track.bone==gripBones[1])track.sample(0,pose[track.bone]);
        }
        if (behavior.equals("chew")) {
            float wave = (float)(.5 + .5 * Math.sin(behaviorTicks * Math.PI * 2 / LivingPresentation.chewPeriod));
            for (int i=0; i<bones.length; i++) if (bones[i].name.equals(LivingPresentation.mouthBone))
                pose[i][7] *= LivingPresentation.mouthMinimum + (LivingPresentation.mouthMaximum - LivingPresentation.mouthMinimum) * wave;
        }
        for (int i = 0; i < bones.length; i++) {
            Bone bone = bones[i];
            float[] v = pose[i];
            Matrix4f matrix = world[i];
            if (bone.parent < 0) matrix.identity();
            else matrix.set(world[bone.parent]);
            matrix.translate(bone.x + v[0], bone.y + v[1], bone.z + v[2])
                    .rotateZYX(v[5] * DEGREES, v[4] * DEGREES, v[3] * DEGREES)
                    .scale(v[6], v[7], v[8]).translate(-bone.x, -bone.y, -bone.z);
        }
        PoseStack.Pose transform = stack.last();
        for (Part part : parts) {
            if(drawingWoundedBody&&io.github.longshou.mcyukkuri.body.WoundSurface.get(id).replaced.contains(part.name))continue;
            if(hairHidden(part,hairLoss))continue;
            if (!accessory && LivingPresentation.variants.get(id).accessoryPrefixes().stream().anyMatch(part.name::startsWith)) continue;
            // Explicit visibility also covers interruption, idle and resource reload.
            if (!part.anatomy.isEmpty() && !action.startsWith("anatomy_" + part.anatomy + "_")) continue;
            for (int first = part.start; first < part.start + part.count; first += 3) {
                for (int corner = 0; corner < 3; corner++) skin(first + corner, triangle[corner]);
                normal.set(triangle[1]).sub(triangle[0]);
                edge.set(triangle[2]).sub(triangle[0]);
                normal.cross(edge);
                if (normal.lengthSquared() < 1.0e-16f) continue;
                normal.normalize();
                // Vanilla entity buffers use quads: repeat the third corner.
                for (int corner = 0; corner < 4; corner++) {
                    int index = Math.min(corner, 2);
                    Vector3f point = triangle[index];
                    int uv = (first + index) * 8 + 3;
                    buffer.addVertex(transform.pose(), point.x / 16, point.y / 16, point.z / 16)
                            .setColor(255, 255, 255, 255).setUv(vertices[uv], vertices[uv + 1])
                            .setOverlay(overlay).setLight(light)
                            .setNormal(transform, normal.x, normal.y, normal.z);
                }
            }
        }
    }

    public boolean woundGeometryCompatible(){return sourceHash.equals(io.github.longshou.mcyukkuri.body.WoundSurface.get(id).runtimeSourceHash);}
    public void renderLiving(String action,float elapsed,PoseStack stack,VertexConsumer buffer,int light,int overlay,
            boolean accessory,String behavior,float behaviorTicks,int hairLoss,io.github.longshou.mcyukkuri.entity.YukkuriEntity entity,
            net.minecraft.client.renderer.MultiBufferSource buffers){
        drawingWoundedBody=WoundRenderer.active(entity);
        if(drawingWoundedBody&&!woundGeometryCompatible()){
            drawingWoundedBody=false;if(!warnedWoundMismatch){org.slf4j.LoggerFactory.getLogger(YukkuriModel.class).warn("Wound attachment disabled for incompatible resource-pack geometry: {}",id);warnedWoundMismatch=true;}
        }
        try{render(action,elapsed,stack,buffer,light,overlay,accessory,behavior,behaviorTicks,hairLoss);
            if(drawingWoundedBody)WoundRenderer.render(entity,world,stack,buffer,buffers,light,overlay);
        }finally{drawingWoundedBody=false;}
    }

    private boolean hairHidden(Part part,int loss){
        if(loss==0||!(part.name.contains("hair")||part.name.contains("bang")||part.name.contains("braid")))return false;
        if((loss&4)!=0)return true;
        if(part.name.contains("bang")||part.name.contains("crown")||part.name.contains("wrap"))return false;
        float x=0;for(int v=part.start;v<part.start+part.count;v++)x+=vertices[v*8];
        return x<0?(loss&1)!=0:(loss&2)!=0;
    }
    /** Place the lowest visible source vertex above the floor during rigid contact poses. */
    public float contactLift(float angle,boolean accessory,int loss){
        float minimum=Float.MAX_VALUE,c=(float)Math.cos(angle*DEGREES),s=(float)Math.sin(angle*DEGREES);
        for(var part:parts){
            if(!part.anatomy.isEmpty()||part.name.contains("puff")||hairHidden(part,loss))continue;
            if(!accessory&&LivingPresentation.variants.get(id).accessoryPrefixes().stream().anyMatch(part.name::startsWith))continue;
            for(int v=part.start;v<part.start+part.count;v++)minimum=Math.min(minimum,(vertices[v*8+1]*c-vertices[v*8+2]*s)/16);
        }
        return minimum==Float.MAX_VALUE?0:.006f-minimum;
    }
    /** The item follows the midpoint of the two actual transformed lock tips. */
    public Vector3f gripPoint(){
        if(!gripping||gripBones==null)return null;
        var result=new Vector3f();
        for(int i=0;i<2;i++)result.add(world[gripBones[i]].transformPosition(new Vector3f(gripPoints[i])));
        return result.div(32);
    }
    private void skin(int index, Vector3f target) {
        int offset = index * 8;
        Binding binding = bindings[index];
        target.set(vertices[offset], vertices[offset + 1], vertices[offset + 2]);
        if (binding.weight > 0) {
            second.set(target);
            world[binding.second].transformPosition(second);
        }
        world[binding.first].transformPosition(target);
        if (binding.weight > 0) target.lerp(second, binding.weight);
    }
}
