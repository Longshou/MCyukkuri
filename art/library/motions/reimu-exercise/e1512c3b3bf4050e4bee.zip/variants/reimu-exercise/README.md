# 灵梦 · 嗯嗯体操

[播放整套体操](preview.html) · [完整动图](taiso.gif) · [动作阶段图](pose-sheet.png) · [含动画的 Blockbench 模型](reimu.bbmodel)

在 `../reimu-hakkei/` 的灵梦基础模型上增加骨骼动画。本轮补齐独立后臀，收短后发下缘露出油臀及小叉形标记；前下腹拉长时保持前表面连续，减轻逐层台阶感；笑眼扩大为参考八景 U 的双弧弯月。当前为 246 方块、145 骨骼、5 段动画。原有默认五官与材质配色保留。

[三项修改前后对比](refinement-comparison.png) · [后臀三姿态](rump-sheet.png)。对比采用同尺度、同角度、同动作时刻；上一版保存在 `before-fixes/`。

| 动画 | 时长 | 行为 |
|---|---:|---|
| `animation.reimu.taiso` | 14 秒，循环 | 转向抬臀、换侧用力、上下伸缩、伸高后左右侧弯、回正休息 |
| `animation.reimu.press` | 4.8 秒，循环 | 两侧转向、压低抬臀、用力表情与轻微摆动、回正 |
| `animation.reimu.exercise_vertical` | 2.62 秒，循环 | 沿用魔理沙已完成的上下伸缩曲线 |
| `animation.reimu.exercise_sides` | 2.36 秒，循环 | 沿用用户选定的魔理沙半速左右侧弯曲线 |
| `animation.reimu.stretch` | 2.8 秒，单次 | 沿用魔理沙单次伸长与恢复曲线 |

整套默认自动播放，也可单独切换各段、暂停拖动进度、查看静止造型、旋转与缩放。完整体操的 14 秒顺序是本次演示编排，不是原作歌曲逐帧对时。五段均写入 `.bbmodel` 与动画 JSON，表情切换也是骨骼轨道，不依赖网页临时切换图片。

## 复用与适配

只读复用了 `../marisa-exercise/` 的前身／后臀分体几何、伸缩、侧弯、单次伸长曲线，以及甩臀曲线。输入快照保存在 `reuse/`，来源与 SHA-256 见 `build-info.json`。臀部独立摆动按源幅度的 65% 混入用力阶段。拉长时前身的深度缩放保持为 1，宽度收窄幅度减半，避免下腹露出重复的水平小台面；其余伸高高度、弯曲和时长沿用源曲线。

身体与后臀使用对应部位的分段骨骼，侧发复用同高度的前身骨骼。面部薄片和大红结跟随上部，两侧红白套饰以较低枢轴跟随。原始 128×128 图集的默认脸与颜色区逐像素保留，新增的用力表情和后臀标记画在空闲区域。后臀标记直接贴在各分段的背面，随身体形变。

转向抬臀根据八景 U 的普通侧向、体操 1、体操 2 图层和 `うんうんたいそう顔()` 的动作阶段制作；转向角度、前部支点、三维厚度、平滑衔接和饰物跟随幅度属于本次适配。[原始参考核读记录](reference/README.md)。

## 文件与验证

- [几何 JSON](reimu.geo.json) / [动画 JSON](reimu.animation.json) / [贴图](reimu.png)。Blockbench 文件含贴图及全部动画。
- [上下伸缩动图](exercise_vertical.gif) / [左右侧弯动图](exercise_sides.gif)，与完整动图均按 50 帧/秒输出。
- `verify.py` 检查身体分体几何与魔理沙输入快照一致、保留的饰物和侧发范围、后发露出高度、默认脸/配色像素、纹理嵌入、骨骼引用、几何与动画导出的一致性，结果为 `verification.json`。
- `verify-motion.cjs` 逐段按 50 帧/秒检查姿态有限值、地面、循环闭合及上下/侧弯相邻皮肤层的分离轴间隙，并核对复用曲线。结果为 `motion-verification.json`；浮点与关键帧简化容差约 0.00003 模型单位。
- `browser-check.cjs` 实测五段动作、时间轴、循环持续、按真实时间播放、静止、拖动缩放及手机布局。结果为 `browser-verification.json`。
- `verify-blockbench.cjs` 在实际 Blockbench 网页编辑器中导入交付文件，对每段 31 个姿态逐方块比较世界坐标包围盒，并核对官方 Bedrock 动画编译结果。结果为 `blockbench-verification.json`。

尚未接入 Minecraft 实体或进行 MC 实机验证。原静态物品展示包仍在基础模型目录；物品展示包不会播放这些骨骼动画。

## 重建

从项目根目录运行（现有 Python NumPy/Pillow、Node、Playwright/Chrome 环境）：

```powershell
python variants/reimu-exercise/generate.py
python variants/reimu-exercise/verify.py
node variants/reimu-exercise/verify-motion.cjs
node variants/reimu-exercise/browser-check.cjs
node variants/reimu-exercise/verify-blockbench.cjs
python variants/reimu-exercise/make-previews.py
```

动图由实际预览使用的同一动画求值器与光栅渲染器生成，以内存流传给 Pillow，不产生逐帧原始图片文件。原作 Sprite 仅位于参考目录，未打包进交付模型。
