# Local convenience launcher; intentionally ignored by Git.
param(
    [Parameter(Position = 0, ValueFromRemainingArguments = $true)]
    [string[]] $GradleArgs = @('build')
)

$ErrorActionPreference = 'Stop'
$projectRoot = Split-Path -Parent $PSScriptRoot
$taskJdk = 'E:/yukkuri/.devtools/mcyukkuri/java/jdk-21.0.12.1+1'
if (-not (Test-Path -LiteralPath "$taskJdk/bin/java.exe")) {
    throw "Local JDK not found: $taskJdk. Install JDK 21 and use gradlew.bat."
}

$previousJavaHome = $env:JAVA_HOME
$previousPath = $env:PATH
$result = 1
Push-Location $projectRoot
try {
    $env:JAVA_HOME = $taskJdk
    $env:PATH = "$taskJdk/bin;$env:PATH"
    $networkArgs = @()
    $internetSettings = Get-ItemProperty 'HKCU:/Software/Microsoft/Windows/CurrentVersion/Internet Settings'
    if ($internetSettings.ProxyEnable -eq 1 -and $internetSettings.ProxyServer -eq '127.0.0.1:7897') {
        $networkArgs = @(
            '-Dhttp.proxyHost=127.0.0.1', '-Dhttp.proxyPort=7897',
            '-Dhttps.proxyHost=127.0.0.1', '-Dhttps.proxyPort=7897',
            '-Dorg.gradle.internal.http.idleConnectionTimeout=1'
        )
    }
    & (Join-Path $projectRoot 'gradlew.bat') @GradleArgs @networkArgs
    $result = $LASTEXITCODE
}
finally {
    Pop-Location
    $env:JAVA_HOME = $previousJavaHome
    $env:PATH = $previousPath
}
exit $result
